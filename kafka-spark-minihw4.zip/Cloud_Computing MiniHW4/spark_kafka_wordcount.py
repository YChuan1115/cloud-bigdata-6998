"""

Spark word count application for streaming data sent to Kafka

Authors:
Dhruv Shekhawat
Kunal Baweja

"""
from __future__ import print_function
import sys
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: spark_kafka_wordcount.py <zkQuorum> <topic>", file=sys.stderr)
        exit(-1)

    sparkcontext = SparkContext(appName="KafkaWordCountStreaming")
    sparkcontext_time = StreamingContext(sparkcontext, 20)                #second parameter to function is the time to refresh Spark

    zkQuorum, topic = sys.argv[1:]
    consumer_stream = KafkaUtils.createStream(sparkcontext_time, zkQuorum, "spark-streaming-consumer", {topic: 1})
    lines = consumer_stream.map(lambda x: x[1])
    wordcount = lines.flatMap(lambda line: line.split(" ")) \
        .map(lambda word: (word, 1)) \
        .reduceByKey(lambda a, b: a+b)


    def process(rdd):
        print("============%s============" % str(rdd.collect()))
        

    wordcount.foreachRDD(process)                                         #prints more than ten results unlike pprint()
    sparkcontext_time.start()                                             #Actual application starts after this command.
    sparkcontext_time.awaitTermination()
